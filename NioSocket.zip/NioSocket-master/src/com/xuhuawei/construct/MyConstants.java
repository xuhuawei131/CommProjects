package com.xuhuawei.construct;

/**
 * Created by Administrator on 2017/10/15 0015.
 */
public class MyConstants {
    public static final int port=8899;
}
